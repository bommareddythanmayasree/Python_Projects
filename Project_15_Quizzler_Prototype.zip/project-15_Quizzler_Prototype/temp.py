str = "Video streaming website YouTube was purchased in it&#039;s"
str = str.replace("&#039;", "'")
print(str)