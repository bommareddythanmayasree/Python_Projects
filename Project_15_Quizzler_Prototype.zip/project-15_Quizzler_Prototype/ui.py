import tkinter
from tkinter import Canvas, Button, PhotoImage
from quiz_brain import QuizBrain

THEME_COLOR = "#375362"

class QuizDesign:
    def __init__(self, question_list:QuizBrain):
        self.question_object = question_list
        self.window = tkinter.Tk()
        self.window.title("Quizzler")
        self.window.config(padx=20, pady=20, bg=THEME_COLOR)

        self.score_label = tkinter.Label(text="Score : ", fg="white", bg=THEME_COLOR)
        self.score_label.grid(row=0, column=0, columnspan=2)

        self.right_button_image = PhotoImage(file="images/true.png")
        self.right_button = Button(image=self.right_button_image, highlightthickness=0, command = self.ans_true)
        self.right_button.grid(row=2, column=0)

        self.wrong_button_image = PhotoImage(file="images/false.png")
        self.wrong_button = Button(image=self.wrong_button_image, highlightthickness=0, command=self.ans_false)
        self.wrong_button.grid(row=2, column=1)

        self.canvas = Canvas(height=250,width=300, bg="white")
        self.question_canvas = self.canvas_question_text = self.canvas.create_text(150, 125, text="Question Text", font=("Arial", 20, "italic"), width=280)
        self.canvas.grid(row=1, column=0, columnspan=2, pady=50)

        self.change_question()
        self.window.mainloop()

    def change_question(self):
        if self.question_object.still_has_questions():
            self.canvas.config(bg="white")
            question_text = self.question_object.next_question()
            self.canvas.itemconfig(self.question_canvas, text=question_text)

        else:
            self.canvas.config(bg="white")
            self.canvas.itemconfig(self.question_canvas, text="QUIZ OVER")
            self.wrong_button.config(state=tkinter.DISABLED)
            self.right_button.config(state=tkinter.DISABLED)

    def ans_true(self):
        answer = self.question_object.check_answer("True")
        print(answer)
        self.feedback(answer)
        self.score_update()

    def ans_false(self):
        answer = self.question_object.check_answer("False")
        print(answer)
        self.feedback(answer)
        self.score_update()

    def score_update(self):
        self.score_label.config(text=f"SCORE : {self.question_object.score}")

    def feedback(self, answer):
        if answer:
            self.canvas.config(bg="green")

        else:
            self.canvas.config(bg="red")

        self.window.after(2000, self.change_question)