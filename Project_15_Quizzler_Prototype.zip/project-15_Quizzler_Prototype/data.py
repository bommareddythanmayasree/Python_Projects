import requests

connection = requests.get(url="https://opentdb.com/api.php?amount=10&type=boolean#")
connection.raise_for_status()
question_data = connection.json()
