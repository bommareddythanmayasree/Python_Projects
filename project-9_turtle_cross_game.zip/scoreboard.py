from turtle import Turtle

FONT = ("Courier", 24, "normal")

class Scoreboard(Turtle):
    def __init__(self):
        super().__init__()
        self.level_no = 1
        self.hideturtle()
        self.penup()
        self.goto(-275, 250)
        self.write(f"LEVEL : {self.level_no}", font=("Courier", 24, "normal"))

    def increase_level(self):
        self.clear()
        self.level_no+=1
        self.write(f"LEVEL : {self.level_no}", font=("Courier", 24, "normal"))