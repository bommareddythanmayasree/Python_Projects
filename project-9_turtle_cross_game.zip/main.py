import time
from turtle import Screen, Turtle
from player import Player
from car_manager import CarManager
from scoreboard import Scoreboard

screen = Screen()
screen.setup(width=600, height=600)
screen.tracer(0)

# OBJECTS
main_turtle = Player()
car_manager_turtle = CarManager()
score_turtle = Scoreboard()
end_turtle = Turtle()

end_turtle.hideturtle()
end_turtle.penup()

# KEY BINDINGS
screen.listen()
screen.onkey(main_turtle.move_forward , "Up")
screen.onkey(main_turtle.move_back , "Down")


game_is_on = True
while game_is_on:
    time.sleep(0.1)
    screen.update()

    car_manager_turtle.create_car()
    car_manager_turtle.move_car()

    for car in car_manager_turtle.all_cars:
        if main_turtle.distance(car) < 20:
            game_is_on = False

    if main_turtle.check_finish():
        main_turtle.go_to_start()
        car_manager_turtle.increase_speed()
        score_turtle.increase_level()


end_turtle.write("GAME OVER!", font=("arial", 15, "bold"), align="center")
screen.exitonclick()