from turtle import Turtle
STARTING_POSITION = (0, -280)
MOVE_DISTANCE = 10
FINISH_LINE_Y = 280


class Player(Turtle):
    def __init__(self):
        super().__init__()
        self.shape("turtle")
        self.color("black")
        self.penup()
        self.left(90)
        self.goto(0,-(FINISH_LINE_Y))

    def move_forward(self):
        self.forward(MOVE_DISTANCE)
        self.check_finish()

    def move_back(self):
        self.back(MOVE_DISTANCE)
        self.check_finish()

    def check_finish(self):
        if self.ycor() >= FINISH_LINE_Y:
            return True
        else:
            return False

    def go_to_start(self):
        self.goto(STARTING_POSITION)
