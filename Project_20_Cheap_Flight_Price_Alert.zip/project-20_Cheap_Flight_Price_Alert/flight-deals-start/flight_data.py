IATA_ENDPOINT = "" # ENTER YOUR CODE
FLIGHT_ENDPOINT = "" # ENTER YOUR CODE
TOKEN_ENDPOINT = "" # ENTER YOUR CODE

import requests
import datetime

class FlightData:

    API_ENDPOINT = "" # ENTER YOUR CODE
    PRICE = 0
    DEPARTURE_AIRPORT_CODE = "" # ENTER YOUR CODE
    DATE_SPAN = datetime.datetime.now() + datetime.timedelta(days=180)
    DATE = DATE_SPAN.strftime("%Y-%m-%d")

    def __init__(self):
        self._api_key = "" # ENTER YOUR CODE
        self._api_secret = "" # ENTER YOUR CODE
        self._token = self._get_new_token()

    def _get_new_token(self):
        header = {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        body = {
            'grant_type': 'client_credentials',
            'client_id': self._api_key,
            'client_secret': self._api_secret
        }
        response = requests.post(url=TOKEN_ENDPOINT, headers=header, data=body)
        # New bearer token. Typically expires in 1799 seconds (30min)
        # print(f"Your token is {response.json()['access_token']}")
        # print(f"Your token expires in {response.json()['expires_in']} seconds")
        return response.json()['access_token']

    def flight_cheapest_flight(self, iata_code, city_name):
        parameters = {
            "originLocationCode" : self.DEPARTURE_AIRPORT_CODE, # I WILL BE TRAVELLING FROM DELHI, INDIA. That's why i have DEL
            "destinationLocationCode" : iata_code,
            "departureDate" : self.DATE,
            "adults" : 1,
            "currencyCode" : "USD"
        }

        headers = {
            "Authorization" : f"Bearer {self._token}"
        }

        self.connection = requests.get(url=self.API_ENDPOINT, params=parameters, headers=headers)
        self.data = self.connection.json()
        try:
            # print(f"{city_name} : {self.data['data'][0]['price']['total']}")
            return self.data['data'][0]['price']['total']
        except:
            # print(f"{city_name} : 'NA'")
            return 'NA'
