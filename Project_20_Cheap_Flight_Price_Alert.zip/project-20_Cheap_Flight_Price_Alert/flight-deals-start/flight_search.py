import requests
IATA_ENDPOINT = "" # ENTER YOUR CODE
FLIGHT_ENDPOINT = ""  # ENTER YOUR CODE
TOKEN_ENDPOINT = "" # ENTER YOUR CODE

class FlightSearch:
    def __init__(self):
        self._api_key = "" # ENTER YOUR CODE
        self._api_secret = "" # ENTER YOUR CODE
        self._token = self._get_new_token()

    def _get_new_token(self):
        header = {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        body = {
            'grant_type': 'client_credentials',
            'client_id': self._api_key,
            'client_secret': self._api_secret
        }
        response = requests.post(url=TOKEN_ENDPOINT, headers=header, data=body)
        # New bearer token. Typically expires in 1799 seconds (30min)
        # print(f"Your token is {response.json()['access_token']}")
        # print(f"Your token expires in {response.json()['expires_in']} seconds")
        return response.json()['access_token']

    def update_iata_codes(self, missing_list, data):
        dict_list = data['sheet1']
        for temp_dict in dict_list:
            if temp_dict['city'] in missing_list:
                parameters = {
                    "keyword" : temp_dict['city']
                }

                headers = {
                    "Authorization" : f"Bearer {self._token}"
                }

                connection = requests.get(url="", params=parameters, headers=headers) # ENTER YOUR CODE
                data_iata = connection.json()
                temp_dict['iataCode'] =  data_iata['data'][0]['iataCode']
        return data