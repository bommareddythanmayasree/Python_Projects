#This file will need to use the DataManager,FlightSearch, FlightData, NotificationManager classes to achieve the program requirements.
from pprint import pprint
import datetime
import data_manager
import flight_search
import flight_data
import notification_manager

DATE_SPAN = datetime.datetime.now() + datetime.timedelta(days=180)
DATE = DATE_SPAN.strftime("%Y-%m-%d")

data_manager_obj = data_manager.DataManager()
flight_search_obj = flight_search.FlightSearch()
flight_data_obj = flight_data.FlightData()
notification_manager_obj = notification_manager.NotificationManager()

sheet_data = data_manager_obj.get_sheet_data()
iata_missing_list = []
temp_list = sheet_data["sheet1"]

# UPDATING IATA CODE IN DATA
for temp_dict in temp_list:
    if temp_dict["iataCode"] == "":
        iata_missing_list.append(temp_dict['city'])

sheet_data = flight_search_obj.update_iata_codes(iata_missing_list, sheet_data)

# UPDATING GOOGLE SHEETS
for temp_dict in temp_list:
    data_manager_obj.update_sheet_data(temp_dict['id'], temp_dict)

# EXTRACTING THE EMAIL ID FROM THE GOOGLE SHEETS
email_IDs = data_manager_obj.get_EMAIL_data()
print(email_IDs)

# CHECKING THE FLIGHT DATA
for temp_dict in temp_list:
    price_in_doc = temp_dict['lowestPrice']
    # print(f"Getting flights for {temp_dict['city']}.....")
    price = flight_data_obj.flight_cheapest_flight(temp_dict['iataCode'], temp_dict['city'])
    # print(f"{temp_dict['city']} : {price}")

    # NOW LET US CHECK WHETHER THE PRICES ARE LESS THAN THE ONES IN THE LIST {if yes then we will send SMS to user}
    if price!='NA':
        if float(price) < float(price_in_doc):
            notification_manager_obj.send_sms(price, temp_dict['iataCode'], "DEL", DATE)
            notification_manager_obj.send_mail(price, temp_dict['iataCode'], "DEL", DATE, email_ID=email_IDs)

