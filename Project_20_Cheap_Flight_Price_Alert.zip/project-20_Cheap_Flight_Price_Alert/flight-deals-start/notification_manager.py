import smtplib
import datetime
from pyexpat.errors import messages
from twilio.rest import Client
class NotificationManager:
    def __init__(self):
        self.smtp_object = smtplib.SMTP()
        self.account_sid = "" # ENTER YOUR CODE
        self.auth_token = "" # ENTER YOUR CODE


    def send_sms(self, price, departure_to, departure_from, date):
        client = Client(self.account_sid, self.auth_token)
        message = client.messages.create(
            to='', # ENTER YOUR CODE
            from_='', # ENTER YOUR CODE
            body= f"" # HAS TO BE FILLED
        )
        print(f"Low Price Alert! Only {price}$ to fly from {departure_from} to {departure_to}, on {datetime.datetime.now().strftime('%Y-%m-%d')} until {date}")

    def send_mail(self, price, departure_to, departure_from, date, email_ID):
        sender_mail = "" # ENTER YOUR CODE
        body_message = f"Low Price Alert! Only {price}$ to fly from {departure_from} to {departure_to}, on {datetime.datetime.now().strftime('%Y-%m-%d')} until {date}"
        smtp_server = "smtp.gmail.com"
        smtp_port = 587

        login_email = "" # ENTER YOUR CODE
        login_app_password = "" # ENTER YOUR CODE

        for temp_mail in email_ID:
            receiver_mail = temp_mail
            try:
                with smtplib.SMTP(smtp_server, smtp_port) as server:
                    server.starttls() # This step Secures the connection
                    server.login(login_email, login_app_password)
                    server.sendmail(sender_mail, receiver_mail, body_message)
                    print('EMAIL SENT SUCCESSFULLY')

            except:
                print('ERROR IN SENDING MAIL')