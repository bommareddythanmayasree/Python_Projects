import requests
from pprint import pprint

class DataManager:
    def __init__(self):
        self.connection_getdata = requests.get(url="") # ENTER YOUR CODE
        self.connection_getEMAIL = requests.get(url="") # ENTER YOUR CODE
        self.data_flight = self.connection_getdata.json()
        self.data_EMAIL = self.connection_getEMAIL.json()

    def get_sheet_data(self):
        return self.data_flight

    def update_sheet_data(self, row_id, content):
        temp_json = {"sheet1" : content}
        self.connection_row_edit = requests.put(url = f"", json=temp_json) # ENTER YOUR CODE

    def get_EMAIL_data(self):
        email_list = []
        for temp_dict in self.data_EMAIL['users']:
            mail_id = temp_dict['whatIsYourEmailId?']
            email_list.append(mail_id)

        return email_list