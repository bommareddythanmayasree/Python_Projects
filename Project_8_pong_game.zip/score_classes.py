from turtle import Turtle

class ScoreBoard(Turtle):
    def __init__(self):
        super().__init__()
        self.color("white")
        self.shape("turtle")
        self.left_score = 0
        self.right_score = 0
        self.penup()
        self.goto(x= 0, y=225)
        self.hideturtle()
        self.score_print()

    def score_print(self):
        self.clear()
        self.write(f"{self.left_score} {self.right_score}", font=('Arial', 50, 'bold'), align="center")

    def right_score_update(self):
        self.right_score += 1
        self.score_print()

    def left_score_update(self):
        self.left_score += 1
        self.score_print()

    def win_check(self):
        if self.left_score == 2:
            self.goto(0, 200)
            self.write("PLAYER 1 - WON!", font=('Arial', 20, 'italic'), align="center")
            return True

        elif self.right_score == 5:
            self.goto(0, 200)
            self.write("PLAYER 2 - WON!", font=('Arial', 20, 'italic'), align="center")
            return True

        else:
            return False

    def score_reset(self):
        self.right_score = 0
        self.left_score = 0