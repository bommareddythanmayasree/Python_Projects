from turtle import Screen
from paddle_classes import Paddle
from ball_classes import Ball
import time
from score_classes import ScoreBoard

# SCORE OBJECT
score = ScoreBoard()

# SCREEN SETTINGS
screen = Screen()
screen.bgcolor("black")
screen.setup(height=600, width=800)
screen.title("Ping Pong")
screen.tracer(0)

# RIGHT PADDLE SETTINGS
right_paddle = Paddle(x=350, y=0)
left_paddle = Paddle(x=-350, y=0)
game_ball = Ball()

screen.listen()

screen.onkey(right_paddle.move_up, "Up")
screen.onkey(right_paddle.move_down, "Down")

screen.onkey(left_paddle.move_up, "w")
screen.onkey(left_paddle.move_down, "s")


game_is_on = True
while game_is_on:
    time.sleep(0.1)
    screen.update()
    game_ball.move()

    if game_ball.ycor() > 280 or game_ball.ycor() < -280:
        game_ball.bounce_y()

    # RIGHT PADDLE BOUNCE
    if right_paddle.distance(game_ball) <50 and game_ball.xcor() == 340:
        game_ball.bounce_x()

    # LEFT PADDLE BOUNCE
    if left_paddle.distance(game_ball) <50 and game_ball.xcor() == -340:
        game_ball.bounce_x()

    # EDGE OF THE SCREEN DETECTION
    if game_ball.xcor()>380:
        game_ball.goto(0,0)
        score.left_score_update()
        screen.update()
        time.sleep(0.5)

        game_ball.x_move = -10
        game_ball.y_move = -10



    if game_ball.xcor() < -380:
        game_ball.goto(0,0)
        score.right_score_update()
        screen.update()
        time.sleep(0.5)

        game_ball.x_move = 10
        game_ball.y_move = 10

    if score.win_check():
        game_is_on = not game_is_on

screen.exitonclick()