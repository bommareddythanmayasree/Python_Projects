from venv import create

import requests
from twilio.rest import Client

account_sid = 'ACb1308652e5861b7694901fe1d73680a2'
auth_token = 'bd636e743156de20f296a84196df1358'

api = "a1b2394289828346d954d42d376a1033"
weather_parameters = {
    "lat" : 44.34,
    "lon" : 10.99,
    "appid" : api
 }

connection = requests.get("https://api.openweathermap.org/data/2.5/forecast?lat=44.34&lon=10.99&exclude=current,minutely,daily&appid=a1b2394289828346d954d42d376a1033#", params=weather_parameters)
connection.raise_for_status()

weather_data_full = connection.json()
weather_data = []
for data in range(0,12):
    weather_data.append(weather_data_full["list"][data])

will_rain = False

for code in weather_data:
    code_number = code["weather"][0]["id"]
    if code_number < 700:
        will_rain = True

if will_rain:
    client = Client(account_sid, auth_token)
    message = client.messages.create(
        body="It's going to Rain Today!",
        from_="+19707075302",
        to="+918463915216",
    )
    print(message.status)