
import requests
import datetime

APP_ID = "fd285007"
API_KEY = "c756ae3648835355af33308dea7bf4ee"
DOMAIN_ENDPOINT = "https://trackapi.nutritionix.com"
EXERCISE_ENDPOINT = "/v2/natural/exercise"
ADD_ROW_ENDPOINT = "https://api.sheety.co/07ec7d416c49fcb7914bacdf2b374e7b/akhilWorkouts/workouts"
TODAY = datetime.date.today()
TIME = datetime.datetime.now().time().strftime("%X")
print(TODAY)
print(TIME)
header = {
    "x-app-id" : APP_ID,
    "x-app-key" : API_KEY
}

params_exercise = {
    "query" : input("What exercise have you done today? : ")
}

connection_nlp = requests.post(url=DOMAIN_ENDPOINT + EXERCISE_ENDPOINT, headers=header, data=params_exercise)
nlp_data = connection_nlp.json()
EXERCISE = nlp_data["exercises"][0]["user_input"]
DURATION = nlp_data["exercises"][0]["duration_min"]
CALORIES = nlp_data["exercises"][0]["nf_calories"]
# ------------------------------------
data_new_row = {
    "workout" : {
        "date" : str(TODAY),
        "time" : str(TIME),
        "exercise" : EXERCISE,
        "duration in min" : DURATION,
        "calories" : CALORIES
    }
}

new_row_header = {
    "Content-Type" : "application/json"
}

connection_row_add = requests.post(url=ADD_ROW_ENDPOINT, json=data_new_row, headers=new_row_header)
if connection_row_add.status_code == 200:
    print("Row ADDED SUCCESSFULLY!")
