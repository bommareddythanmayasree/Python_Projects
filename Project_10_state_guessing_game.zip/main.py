import turtle
import pandas

score = 0

screen = turtle.Screen()
screen.title("U.S. States Game")

data = pandas.read_csv("50_states.csv")

all_states = data["state"].to_list()
# all_xcor = data["x"].to_list()
# all_ycor = data["y"].to_list()


image_link = "blank_states_img.gif"
screen.addshape(image_link)
turtle.shape(image_link)
guessed_states = []

while(len(guessed_states) < 50):
    user_state = screen.textinput(title=f"States guessed : {score}/50", prompt="Enter state :").title()

    if user_state == "Exit":
        missing_states = []
        for states in all_states:
            if states not in guessed_states:
                missing_states.append(states)

        new_data = pandas.DataFrame(missing_states)
        new_data.to_csv("Missed States.csv")
        break

    if user_state in all_states:
        if user_state in guessed_states:
            continue

        guessed_states.append(user_state)
        score+=1
        timmy = turtle.Turtle()
        timmy.hideturtle()
        timmy.penup()
        state_data = data[data['state'] == user_state]
        timmy.goto(int(state_data.x), int(state_data.y))
        timmy.write(user_state)

screen.exitonclick()