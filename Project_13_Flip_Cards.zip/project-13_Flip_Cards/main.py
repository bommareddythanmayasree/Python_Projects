import tkinter
from tkinter import Canvas, PhotoImage, Button
import pandas
import random

from six import text_type
global temp_dict
global list_data
# FILE HANDLING -----------------------------------------------------------
try:
    data = pandas.read_csv("data/words_to_learn.csv")
except FileNotFoundError:
    original_data = pandas.read_csv("data/french_words.csv")
    print(original_data)
    list_data = original_data.to_dict(orient="records")
else:
    list_data = data.to_dict(orient="records")

# BUTTON FUNCTIONS --------------------------------------------------------
def next_slide():
    # canvas.itemconfig(bg_image, card_front_image)
    global temp_dict
    canvas.itemconfig(bg_image, image=card_front_image)
    temp_dict = random.choice(list_data)
    canvas.itemconfig(language_text, text="French", fill="black")
    canvas.itemconfig(matter_text, text=temp_dict["French"], fill="black")
    window.after(3000, func=flip_card)

def flip_card():
    canvas.itemconfig(bg_image, image=card_back_image)
    canvas.itemconfig(language_text, text="English", fill="white")
    canvas.itemconfig(matter_text, text=temp_dict["English"], fill="white")

def is_known():
    global temp_dict
    list_data.remove(temp_dict)
    data_frame = pandas.DataFrame(list_data)
    data_frame.to_csv("data/words_to_learn.csv", index=False)
    next_slide()

# UI DESIGN ----------------------------------------------------------------


BACKGROUND_COLOR = "#B1DDC6"
window = tkinter.Tk()
window.title("Flip Cards")
window.config(padx=50, pady=50, bg=BACKGROUND_COLOR)
window.after(3000, func=flip_card)

canvas = Canvas(height=526, width=800)
card_front_image = PhotoImage(file="images/card_front.png")
card_back_image = PhotoImage(file="images/card_back.png")
bg_image = canvas.create_image(400, 263, image = card_front_image)
language_text = canvas.create_text(400, 150, text="Title", font=("Arial", 30, "normal"))
matter_text = canvas.create_text(400, 263, text="Word", font = ("Ariel", 60, "bold"))
canvas.config(bg=BACKGROUND_COLOR, highlightthickness=0)
canvas.grid(row=0, column=0, columnspan=2)

cross_image = PhotoImage(file="images/wrong.png")
cross_button = Button(image=cross_image, command=next_slide)
cross_button.config(highlightthickness=0)
cross_button.grid(row=1, column=0)

right_image = PhotoImage(file="images/right.png")
right_button = Button(image=right_image, command=is_known)
right_button.config(highlightthickness=0 )
right_button.grid(row=1, column=1)

next_slide()

window.mainloop()
