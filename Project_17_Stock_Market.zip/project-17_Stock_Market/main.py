import requests
from twilio.rest import Client
STOCK_NAME = "TSLA"
COMPANY_NAME = "Tesla Inc"
API_LINK = "https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=TSLA&apikey=C5U4VYIQRFKWJFMW"
STOCK_ENDPOINT = "https://www.alphavantage.co/query"
NEWS_ENDPOINT = "https://newsapi.org/v2/everything"

connection = requests.get(url="https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=TSLA&apikey=C5U4VYIQRFKWJFMW")
print(connection.status_code)
data = connection.json()
filtered_data = data["Time Series (Daily)"]
i=0
for temp in filtered_data:
    i+=1
    yesterday_price = filtered_data[temp]["4. close"]
    if i == 1:
        break

print(yesterday_price)

for temp in filtered_data:
    i+=1
    day_before_yesterday_price = filtered_data[temp]["4. close"]
    if i==3:
        break

print(day_before_yesterday_price)

difference = abs(float(yesterday_price) - float(day_before_yesterday_price))
print(difference)


average = (float(yesterday_price)+float(day_before_yesterday_price))/2
percentage_difference = round((float(difference)/float(average))*100, 2)
print(f"Percentage Difference : {percentage_difference}%")


# if percentage_difference>5:
news_connection = requests.get(url="https://newsapi.org/v2/everything?q=tesla&from=2024-08-16&sortBy=publishedAt&apiKey=bea6034b823d41dfa2ef4ef8b507c535#")
news_data = news_connection.json()

news_data = news_data["articles"]
articles_list = news_data[0:3:1]
news_list = []
for item in articles_list:
    temp_dict = {
        "Headlines" : item["title"],
        "Content" : item["content"]
    }
    news_list.append(temp_dict)
print(news_list)

account_sid = 'ACb1308652e5861b7694901fe1d73680a2'
auth_token = 'bd636e743156de20f296a84196df1358'
client = Client(account_sid, auth_token)
print(len(news_list))
for item in news_list:
    message = client.messages.create(
        from_='+19707075302',
        to='+918463915216',
        body=f"Headline : {item['Headlines']}\nBrief : {item['Content']}"
    )
    print('MESSAGE SENT')


