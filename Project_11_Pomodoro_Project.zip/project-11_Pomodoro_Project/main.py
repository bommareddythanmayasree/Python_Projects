import tkinter
import math
from itertools import count
from turtledemo.penrose import start

window = tkinter.Tk()
window.title("Promodoro")


PINK = "#e2979c"
RED =  "#e7305b"
GREEN = "#9bdeac"
YELLOW = "#f7f5dd"
FONT_NAME = "Courier"
WORK_MIN = 1
SHORT_BREAK_MIN = 5
LONG_BREAK_MIN = 20
REPS = 0
TICK = ""
RESET = None

# TIMER RESET
def reset_timer():
    global REPS, TICK
    REPS = 0
    TICK = ""
    timer_text.config(text="TIMER", fg=GREEN)
    canvas.itemconfig(count_down_text, text=f"00:00")
    tick_text.config(text=TICK)
    window.after_cancel(RESET)

# TIMER MECHANISM

def start_time():
    global REPS
    REPS+=1
    work_sec = WORK_MIN*60
    short_break = SHORT_BREAK_MIN*60
    long_break = LONG_BREAK_MIN*60

    if REPS%2!=0:
        timer_text.config(text="WORK", fg=GREEN)
        count_down(work_sec)

    elif REPS%2==0 and REPS%8!=0:
        timer_text.config(text="SHORT-BREAK", fg=PINK)
        count_down(short_break)

    else:
        timer_text.config(text="LONG-BREAK", fg=RED)
        count_down(long_break)

# COUNTDOWN MECHANISM

def count_down(count):
    global TICK, RESET
    min_count = math.floor(count/60)
    sec_count = count%60

    if min_count<=9:
        min_count = f"0{min_count}"

    if sec_count<=9:
        sec_count=f"0{sec_count}"

    if count ==-1:
        return

    canvas.itemconfig(count_down_text, text=f"{min_count} : {sec_count}")
    if count>0:
        RESET = window.after(1000, count_down, count-1)

    else:

        start_time()
        if REPS%2==0:
            TICK = TICK+"✅"
        tick_text.config(text=TICK)


# UI SETUP
window.config(padx=30, pady=30, bg=YELLOW)

timer_text = tkinter.Label(text="Timer", font=(FONT_NAME, 25, "bold"), fg=GREEN, bg=YELLOW)
timer_text.grid(row=0, column=1)

start_button = tkinter.Button(text="Start", command=start_time)
start_button.config(padx=15)
start_button.grid(row=2, column=0)

reset_button = tkinter.Button(text="Reset", command=reset_timer)
reset_button.config(padx=15)
reset_button.grid(row=2, column=2)

tick_text = tkinter.Label(bg = YELLOW)
tick_text.grid(row=3, column=1)

canvas = tkinter.Canvas(width=370, height=310, bg=YELLOW, highlightthickness=0)
image_link = tkinter.PhotoImage(file = "tomato.png")
canvas.create_image(185, 155, image=image_link)
count_down_text = canvas.create_text(185, 155, text="00:00", font=(FONT_NAME, 50, "bold"), fill="White")



canvas.grid(column=1, row=1)

window.mainloop()