import tkinter
from tkinter import PhotoImage
from tkinter import messagebox
import random
import pyperclip

window = tkinter.Tk()
window.title("Password Manager")
window.config(padx=25, pady=25)

# FILE OPENING
file_pointer = open("data.txt", 'a')

# PASSWORD GENERATOR
def generate_password():
    letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    symbols = ['!', '#', '$', '%', '&', '(', ')', '*', '+']

    nr_letters = random.randint(8, 10)
    nr_symbols = random.randint(2, 4)
    nr_numbers = random.randint(2, 4)

    password_list = []

    for char in range(nr_letters):
      password_list.append(random.choice(letters))

    for char in range(nr_symbols):
      password_list += random.choice(symbols)

    for char in range(nr_numbers):
      password_list += random.choice(numbers)

    random.shuffle(password_list)

    password = ""
    for char in password_list:
      password += char

    password_text = password_entry.get()
    password_entry.delete(0, last=int(len(password_text)))
    password_entry.insert(0, password)
    pyperclip.copy(password)

# SAVE PASSWORD
def save():
    website_text = website_name_entry.get()
    email_text = email_username_entry.get()
    password_text = password_entry.get()

    if website_text=="" or email_text == "" or password_text == "":
        messagebox.showerror(title="Invalid Entry", message="Please fill all"
                                                            " the slots")
        return

    is_ok = messagebox.askyesno(title=website_text, message=f"Entered details are :\nEmail :"
                                                            f" {email_text}\nPassword : {password_text}\n"
                                                            f"Are you sure you want to save the details?")

    if is_ok:
        input_string = f"{website_text} | {email_text} | {password_text}\n"
        file_pointer.write(input_string)

        website_name_entry.delete(first=0, last=int(len(website_text)))
        password_entry.delete(first=0, last=int(len(password_text)))
        email_username_entry.delete(first=0, last=int(len(email_text)))
        email_username_entry.insert(0, "akhilesh112606@gmail.com")

# UI SETUP

canvas = tkinter.Canvas(height=200, width=200)
logo_image = PhotoImage(file="resizedlogo.png")
canvas.create_image(100,100, image=logo_image)
canvas.grid(row=0, column = 1)


website_label = tkinter.Label(text="Website :")
website_label.grid(row=1, column=0)

email_username_label = tkinter.Label(text="Email/Username :")
email_username_label.grid(row=2, column=0)

password_label = tkinter.Label(text="Password :")
password_label.grid(row=3, column=0)

website_name_entry = tkinter.Entry(width=35)
website_name_entry.grid(row=1, column=1, columnspan=2)
website_name_entry.focus()

email_username_entry = tkinter.Entry(width=35)
email_username_entry.grid(row=2, column=1, columnspan=2)
email_username_entry.insert(0, "akhilesh112606@gmail.com")

password_entry = tkinter.Entry(width=17)
password_entry.grid(row=3, column=1)

generate_password_button = tkinter.Button(text="Generate Password", command=generate_password)
generate_password_button.grid(row=3, column=2)

add_button = tkinter.Button(text="Add", width=30, command=save)
add_button.grid(row=4, column=1, columnspan=2)

window.mainloop()
file_pointer.close()