import requests
from datetime import datetime

USERNAME = "akhilfsmb"
TOKEN = "asdflkjsdfkjaA"
GRAPH_ID= "graphtemplate1"
pixela_endpoint = "https://pixe.la/v1/users"
graph_endpoint = f"{pixela_endpoint}/{USERNAME}/graphs"
pixel_endpoint = f"{pixela_endpoint}/{USERNAME}/graphs/{GRAPH_ID}"
today = datetime.now()
DATE = today.strftime("%Y%m%d")
update_pixel_endpoint = f"{pixela_endpoint}/{USERNAME}/graphs/{GRAPH_ID}/{DATE}"

headers = {
    "X-USER-TOKEN" : TOKEN
}

user_params = {
    "token" : TOKEN,
    "username" : USERNAME,
    "agreeTermsOfService" : "yes",
    "notMinor" : "yes"
}

# TO CREATE AN ACCOUNT FOR PROGRESS TRACK ------------------------------------------------------------------------------

# connection_acc_create = requests.post(url=pixela_endpoint, json=user_params)
# print(connection_acc_create.text)

# TO CREATE A GRAPH THROUGH WHICH YOU CAN TRACK YOUR PROGRESS ----------------------------------------------------------

# graph_params = {
#     "id" : "graphtemplate1",
#     "name" : "Study Graph",
#     "unit" : "Hours",
#     "type" : "int",
#     "color" :  "momiji",
# }
#

# connection_graph = requests.post(url=graph_endpoint, json=graph_params, headers=headers )
# print(connection_graph.text)

# TO UPDATE A PIXEL OF TRACKING WHICH YOU HAVE MARKED ------------------------------------------------------------------

# update_pixel_params = {
#     "date" : DATE,
#     "quantity" : input("To what number you want to update : "),
# }
# connection_update_pixel = requests.put(url=update_pixel_endpoint, json=update_pixel_params , headers=headers)
# print(connection_update_pixel.text)

# TO DELETE A PIXEL OF TRACKING WHICH YOU HAVE ALREADY SUBMITTED -------------------------------------------------------

# delete_pixel_params = {
#     "date" : DATE,
# }
# connection_delete_pixel = requests.delete(url=update_pixel_endpoint, json= delete_pixel_params, headers=headers)
# print(connection_delete_pixel.text)
